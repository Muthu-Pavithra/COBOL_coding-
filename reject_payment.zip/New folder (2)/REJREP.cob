       IDENTIFICATION DIVISION.
       PROGRAM-ID. REJREP.

       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT SYSIN ASSIGN TO "INPUT.txt"
               ORGANIZATION IS LINE SEQUENTIAL.
           SELECT SYSOUT ASSIGN TO "OUTPUT.txt"
               ORGANIZATION IS LINE SEQUENTIAL.

       DATA DIVISION.
       FILE SECTION.

       FD SYSIN.
       01 IN-RECORD              PIC X(80).

       FD SYSOUT.
       01 OUT-RECORD             PIC X(80).

       WORKING-STORAGE SECTION.
       01 WS-N                   PIC 9(5) VALUE 0.
       01 WS-I                   PIC 9(5) VALUE 0.
       01 WS-ACCEPTED            PIC 9(5) VALUE 0.
       01 WS-REJECTED            PIC 9(5) VALUE 0.

       01 WS-PAY-ID              PIC X(10).
       01 WS-AMOUNT-TEXT         PIC X(10).
       01 WS-AMOUNT              PIC S9(5) VALUE 0.
       01 WS-STATUS              PIC X(10).

       01 WS-ACCEPTED-OUT        PIC Z(4)9.
       01 WS-REJECTED-OUT        PIC Z(4)9.

       01 WS-REJ-TABLE.
          05 WS-REJ-ID           PIC X(10)
             OCCURS 10000 TIMES.

       PROCEDURE DIVISION.
       MAIN-LOGIC.

           OPEN INPUT SYSIN
           OPEN OUTPUT SYSOUT

           READ SYSIN
           MOVE IN-RECORD TO WS-AMOUNT-TEXT
           COMPUTE WS-N =
               FUNCTION NUMVAL(WS-AMOUNT-TEXT)

           PERFORM VARYING WS-I FROM 1 BY 1
               UNTIL WS-I > WS-N

               READ SYSIN
               MOVE SPACES TO WS-PAY-ID
               MOVE SPACES TO WS-AMOUNT-TEXT
               MOVE SPACES TO WS-STATUS

               UNSTRING IN-RECORD
                   DELIMITED BY ALL SPACE
                   INTO WS-PAY-ID
                        WS-AMOUNT-TEXT
                        WS-STATUS
               END-UNSTRING

               COMPUTE WS-AMOUNT =
                   FUNCTION NUMVAL(WS-AMOUNT-TEXT)

               IF WS-AMOUNT > 0
                   AND WS-STATUS = "READY"
                   ADD 1 TO WS-ACCEPTED
               ELSE
                   ADD 1 TO WS-REJECTED
                   MOVE WS-PAY-ID
                     TO WS-REJ-ID(WS-REJECTED)
               END-IF

           END-PERFORM

           MOVE WS-ACCEPTED TO WS-ACCEPTED-OUT
           MOVE SPACES TO OUT-RECORD
           STRING "Accepted: "
               FUNCTION TRIM(WS-ACCEPTED-OUT)
               INTO OUT-RECORD
           END-STRING
           WRITE OUT-RECORD

           MOVE WS-REJECTED TO WS-REJECTED-OUT
           MOVE SPACES TO OUT-RECORD
           STRING "Rejected: "
               FUNCTION TRIM(WS-REJECTED-OUT)
               INTO OUT-RECORD
           END-STRING
           WRITE OUT-RECORD

           PERFORM VARYING WS-I FROM 1 BY 1
               UNTIL WS-I > WS-REJECTED
               MOVE WS-REJ-ID(WS-I) TO OUT-RECORD
               WRITE OUT-RECORD
           END-PERFORM

           CLOSE SYSIN
           CLOSE SYSOUT

           STOP RUN.